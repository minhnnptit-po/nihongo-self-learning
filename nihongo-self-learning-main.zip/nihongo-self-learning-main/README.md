Web luyện tiếng Nhật do mình làm để hỗ trợ bản thân trong quá trình học tiếng Nhật.

Có 3 chế độ:
|-----------------|-------------------------------------------------------------------------|
|   Chế độ        |                        Nội dung                                         |
|-----------------|-------------------------------------------------------------------------|
|   Hiragana      | Bảng cơ bản, đục âm/bán đục âm, âm ghép, từ vựng ví dụ                  |
|   Katakana      | Bảng cơ bản, đục âm/bán đục âm, âm ghép, từ vựng ví dụ (từ mượn)        |
|   Thể て        | Nhìn động từ thể ます, gõ romaji của thể て, nộp bài để xem điểm         |
|-----------------|-------------------------------------------------------------------------|

## Cấu trúc 
```
index.html           -Khung trang
index.css            -Giao diện web
data.js              -Chỉ chứa dữ liệu (chữ, từ vựng, thể て, kanji...), muốn thêm/sửa chữ thì sửa ở đây
index.js             -Logic web (chấm bài, tiến độ, chuyển chế độ, hiệu ứng)
logo-transparent.png -Logo web (hiện góc trái trên cùng, nền trong suốt để lộ vòng kính lỏng phía sau)
logo.png             -Bản logo gốc nền trắng (không còn dùng trong trang, giữ lại để làm bản gốc)
favicon.png          -Icon trên thẻ trình duyệt (hình tròn, nền trong suốt)
```
`data.js` phải được nạp trước `index.js` (đã sắp sẵn trong `index.html`). Không cần server, mở trực tiếp file vẫn chạy.

## Cách chạy

1. Đặt 6 file (`index.html`, `index.css`, `data.js`, `index.js`, `logo-transparent.png`, `favicon.png`) vào cùng một thư mục.
2. Mở `index.html` bằng trình duyệt.

## Tính năng

**Logo + menu (góc trái trên cùng):** logo hình tròn (90px, vòng kính lỏng trong suốt) và nút 3 gạch (64px) đều đứng yên ở góc trái khi cuộn xuống, đi theo người dùng nên lúc nào cũng bấm được. Điện thoại thì hai nút nhỏ hơn chút. Muốn đổi cỡ thì sửa biến `--logo` và `--ham` ở đầu mục logo trong `index.css`. Bấm logo để về trang chủ (cuộn lên đầu trang, giữ nguyên chế độ đang chọn). Nút 3 gạch ngay dưới logo mở thanh chọn chế độ, tiến độ và bộ lọc (kể cả Xáo trộn / Ẩn nghĩa của Kanji). Bấm lại nút, bấm ra ngoài hoặc nhấn Esc để đóng; chọn chế độ xong thanh tự đóng.

**Hiragana / Katakana** là object gồm 4 nhóm `gojuon`, `dakuten`, `yoon`, `vidu`. Mỗi mục là một mảng:
```
["し", ["shi", "si"]]                 // chữ, các cách gõ đúng
["あさ", "asa", "buổi sáng"]          // từ vựng: thêm nghĩa ở vị trí thứ 3
```

**Thể て** là mảng `て`, mỗi mục gồm 4 phần tử:
```
["おきます", "thức dậy", "おきて", "okite"]

```
Khi chấm thể て,  nguyên âm đôi `ou`/`uu`/`ii`/`ee`/`aa` tính như nguyên âm đơn.
Ví dụ: `benkyoushite` và `benkyoshite` đều được chấp nhận.

**Kanji** (`KANJI_RAW.n5` trong `data.js`): mỗi mục gồm chữ Hán, âm Hán Việt (`kanjiAns(...)`), và chuỗi `"nghĩa\nOn: ... ・ Kun: ..."`.
```
["安", kanjiAns("an", "yên"), "Yên lành, an toàn, rẻ\nOn: アン ・ Kun: やす（い）"]
```
Thẻ hiện sẵn chữ Hán + âm Hán Việt + nghĩa. Người học gõ romaji của **một trong các âm On hoặc Kun** (đáp án tự sinh từ dòng On/Kun, gồm cả dạng có okurigana như `yasui`).
Dòng On/Kun bằng kana chỉ hiện ra khi trả lời đúng (hoặc bấm xem đáp án).
Nút **Ẩn nghĩa / Hiện nghĩa** (cạnh nút Xáo trộn, chỉ có ở mode Kanji) ẩn âm Hán Việt + nghĩa dưới chữ Hán để tự kiểm tra; lựa chọn được nhớ qua localStorage.
Khi chấm, `si/shi`, `tu/tsu`, `sya/sha`... và nguyên âm kéo dài `ou/oo/uu/ii/ee/aa` đều được chấp nhận.

**Lưu tiến độ**: các câu đã trả lời đúng của từng chế độ được lưu trong `localStorage` của trình duyệt (khoá `nihongo-progress-v1`), tải lại trang không bị mất. Thể て lưu cả câu đã gõ đúng và câu đã xem đáp án. "Làm lại từ đầu" chỉ xoá tiến độ của chế độ đang mở. Câu chỉ bấm xem đáp án (ở các chế độ dạng thẻ) không tính là đúng nên không được lưu.

**Gợi ý**: gõ sai 2 lần (2 đáp án sai khác nhau) trên cùng một câu thì hiện thêm chữ cái đầu của đáp án (nhiều đáp án hợp lệ thì liệt kê các chữ đầu khác nhau). Đáp án chỉ có 1 chữ cái thì không gợi ý.

**Nguồn dữ liệu kanji**: các âm On/Kun được đối chiếu với bộ dữ liệu [kanji-data](https://github.com/davidluzgouveia/kanji-data) (dẫn xuất từ KANJIDIC của EDRDG, giấy phép CC BY-SA 4.0). Chỉ bổ sung những âm phổ biến còn thiếu (ví dụ 三 `み/みつ`, 四 `よん`), bỏ qua dạng tiền tố và biến âm hiếm.

## Font:
`--font-ui` cho chữ giao diện (Be Vietnam Pro),
`--font-kana` cho chữ Nhật (Shippori Mincho).

